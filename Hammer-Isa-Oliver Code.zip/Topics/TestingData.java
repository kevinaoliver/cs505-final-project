package cs505-final-project.Topics;

import java.util.List;

public class TestingData {

    public int testing_id;
    public String patient_name;
    public String patient_mrn;
    public int patient_zipcode;
    public int patient_status;
    public List<String> contact_list;
    public List<String> event_list;

    public  TestingData() {

    }

}
